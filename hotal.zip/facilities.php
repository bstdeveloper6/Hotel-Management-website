<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arham's Hotal - Facilities</title> 
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">

    <?php  require('include/links.php')?>
    <style>
      .pop:hover {
        border-top-color: #2ec1ac !important ;
        transform: scale(1.03);
        transition: all 0.3s;
      }
    </style>
</head>
    <body class="bg-light">

    <?php  require('include/header.php')?>


    <div class="my-5 px-4">
      <h2 class="fw-bold h-font text-center" >Our Facilities</h2>
      <div class="h-line bg-warning"></div>
      <p class="mt-3 text-center">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus error perspiciatis nostrum ut aliquid,<br> in magnam molestias commodi! Repudiandae, sed.
      </p>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 mb-5 px-4">
          <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
            <div class="d-flex align-items-center mb-2">
              <img src="images/Features/wifi_img.jpeg" width="40px" alt="">
              <h5 class="m-0 ms-2">Wifi</h5>
            </div>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit nihil molestiae totam iste! Consequatur, labore vero.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-5 px-4">
          <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
            <div class="d-flex align-items-center mb-2">
              <img src="images/Features/wifi_img.jpeg" width="40px" alt="">
              <h5 class="m-0 ms-2">Wifi</h5>
            </div>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit nihil molestiae totam iste! Consequatur, labore vero.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-5 px-4">
          <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
            <div class="d-flex align-items-center mb-2">
              <img src="images/Features/wifi_img.jpeg" width="40px" alt="">
              <h5 class="m-0 ms-2">Wifi</h5>
            </div>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit nihil molestiae totam iste! Consequatur, labore vero.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-5 px-4">
          <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
            <div class="d-flex align-items-center mb-2">
              <img src="images/Features/wifi_img.jpeg" width="40px" alt="">
              <h5 class="m-0 ms-2">Wifi</h5>
            </div>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit nihil molestiae totam iste! Consequatur, labore vero.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-5 px-4">
          <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
            <div class="d-flex align-items-center mb-2">
              <img src="images/Features/wifi_img.jpeg" width="40px" alt="">
              <h5 class="m-0 ms-2">Wifi</h5>
            </div>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit nihil molestiae totam iste! Consequatur, labore vero.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-5 px-4">
          <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
            <div class="d-flex align-items-center mb-2">
              <img src="images/Features/wifi_img.jpeg" width="40px" alt="">
              <h5 class="m-0 ms-2">Wifi</h5>
            </div>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit nihil molestiae totam iste! Consequatur, labore vero.</p>
          </div>
        </div>
      </div>
    </div>
  


    <?php  require('include/footer.php')?>

       
</body>
</html>